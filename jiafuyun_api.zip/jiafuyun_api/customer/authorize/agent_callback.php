<?php


//写入超全局变量
$_REQUEST['service'] = 'Zhianbao_Regulator_WeChat_AgentAuthorize_FansInfoGet';

require_once(dirname(dirname(__FILE__)) . '/index.php');