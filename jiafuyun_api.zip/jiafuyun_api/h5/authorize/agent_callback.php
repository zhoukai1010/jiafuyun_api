<?php


//写入超全局变量
$_REQUEST['service'] = 'Wechat_WebAuth_FansInfoGet';

require_once(dirname(dirname(__FILE__)) . '/index.php');