CREATE TABLE `phalapi_task_mq` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `service` varchar(200) DEFAULT '' COMMENT '接口服务名称',
    `params` text COMMENT 'json格式的参数',
    `create_time` int(11) DEFAULT '0',
    `ext_data` text COMMENT 'json data here',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `phalapi_task_mq_0` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `service` varchar(200) DEFAULT '' COMMENT '接口服务名称',
    `params` text COMMENT 'json格式的参数',
    `create_time` int(11) DEFAULT '0',
    `ext_data` text COMMENT 'json data here',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `phalapi_task_mq_1` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `service` varchar(200) DEFAULT '' COMMENT '接口服务名称',
    `params` text COMMENT 'json格式的参数',
    `create_time` int(11) DEFAULT '0',
    `ext_data` text COMMENT 'json data here',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `phalapi_task_mq_2` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `service` varchar(200) DEFAULT '' COMMENT '接口服务名称',
    `params` text COMMENT 'json格式的参数',
    `create_time` int(11) DEFAULT '0',
    `ext_data` text COMMENT 'json data here',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `phalapi_task_mq_3` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `service` varchar(200) DEFAULT '' COMMENT '接口服务名称',
    `params` text COMMENT 'json格式的参数',
    `create_time` int(11) DEFAULT '0',
    `ext_data` text COMMENT 'json data here',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `phalapi_task_mq_4` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `service` varchar(200) DEFAULT '' COMMENT '接口服务名称',
    `params` text COMMENT 'json格式的参数',
    `create_time` int(11) DEFAULT '0',
    `ext_data` text COMMENT 'json data here',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `phalapi_task_mq_5` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `service` varchar(200) DEFAULT '' COMMENT '接口服务名称',
    `params` text COMMENT 'json格式的参数',
    `create_time` int(11) DEFAULT '0',
    `ext_data` text COMMENT 'json data here',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `phalapi_task_mq_6` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `service` varchar(200) DEFAULT '' COMMENT '接口服务名称',
    `params` text COMMENT 'json格式的参数',
    `create_time` int(11) DEFAULT '0',
    `ext_data` text COMMENT 'json data here',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `phalapi_task_mq_7` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `service` varchar(200) DEFAULT '' COMMENT '接口服务名称',
    `params` text COMMENT 'json格式的参数',
    `create_time` int(11) DEFAULT '0',
    `ext_data` text COMMENT 'json data here',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `phalapi_task_mq_8` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `service` varchar(200) DEFAULT '' COMMENT '接口服务名称',
    `params` text COMMENT 'json格式的参数',
    `create_time` int(11) DEFAULT '0',
    `ext_data` text COMMENT 'json data here',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `phalapi_task_mq_9` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `service` varchar(200) DEFAULT '' COMMENT '接口服务名称',
    `params` text COMMENT 'json格式的参数',
    `create_time` int(11) DEFAULT '0',
    `ext_data` text COMMENT 'json data here',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

