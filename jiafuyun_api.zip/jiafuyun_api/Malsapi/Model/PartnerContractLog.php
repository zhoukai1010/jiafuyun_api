<?php

class Model_PartnerContractLog extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
        return 'jfy_partner_contract_log';
    }
}
