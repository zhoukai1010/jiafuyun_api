<?php

class Model_Yuyue extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
        return 'jfy_yuyue';
    }
}
