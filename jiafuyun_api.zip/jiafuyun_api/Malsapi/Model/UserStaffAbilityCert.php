<?php

class Model_UserStaffAbilityCert extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
        return 'jfy_user_staff_ability_cert';
    }
}
