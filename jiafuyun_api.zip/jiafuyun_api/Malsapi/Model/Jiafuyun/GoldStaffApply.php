<?php

class Model_Jiafuyun_GoldStaffApply extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'jfb_company_gold_apply';
        return 'jfy_company_gold_apply';
    }
}
