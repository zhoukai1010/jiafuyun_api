<?php

class Model_Jiafuyun_StaffApplyLog extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'jfb_company_staff_apply_log';
        return 'jfy_company_staff_apply_log';
    }
}
