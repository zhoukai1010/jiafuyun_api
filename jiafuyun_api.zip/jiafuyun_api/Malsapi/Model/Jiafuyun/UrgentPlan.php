<?php

class Model_Jiafuyun_UrgentPlan extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'zab_urgent_plan';
        return 'jfy_urgent_plan';
    }
}
