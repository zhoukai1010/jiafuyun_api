<?php

class Model_Jiafuyun_CompanyHouseStaff extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'jfb_company_house_staff';
        return 'jfy_company_house_staff';
    }
}
