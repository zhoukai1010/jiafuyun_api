<?php

class Model_Jiafuyun_CompanyStaffAbilityCert extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'jfb_company_staff_ability_cert';
        return 'jfy_company_staff_ability_cert';
    }
}
