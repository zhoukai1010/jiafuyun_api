<?php

class Model_Jiafuyun_CompanyHouseStaffCard extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'jfb_company_house_staff_card';
        return 'jfy_company_house_staff_card';
    }
}
