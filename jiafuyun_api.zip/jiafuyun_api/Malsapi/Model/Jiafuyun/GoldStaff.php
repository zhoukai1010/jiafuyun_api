<?php

class Model_Jiafuyun_GoldStaff extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'jfb_gold_staff';
        return 'jfy_gold_staff';
    }
}
