<?php

class Model_Jiafuyun_RegulatorToCustomer extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'zab_regulator_to_company';
        return 'jfy_regulator_to_company';
    }
}
