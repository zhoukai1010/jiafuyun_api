<?php

class Model_Jiafuyun_OrderAppraise extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'jfb_order_appraise';
        return 'jfy_order_appraise';
    }
}
