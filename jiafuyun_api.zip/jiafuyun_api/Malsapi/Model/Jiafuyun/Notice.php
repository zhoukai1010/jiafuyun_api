<?php

class Model_Jiafuyun_Notice extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'zab_notice';
        return 'jfy_notice';
    }
}
