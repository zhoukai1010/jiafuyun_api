<?php

class Model_Jiafuyun_GoldStaffApplyLog extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'jfb_company_gold_apply_log';
        return 'jfy_company_gold_apply_log';
    }
}
