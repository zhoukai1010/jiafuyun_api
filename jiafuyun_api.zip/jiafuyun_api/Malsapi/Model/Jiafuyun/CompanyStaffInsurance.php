<?php

class Model_Jiafuyun_CompanyStaffInsurance extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'jfb_company_staff_insurance';
        return 'jfy_company_staff_insurance';
    }
}
