<?php

class Model_Jiafuyun_RegulatorLoginLog extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'zab_regulator_login_log';
        return 'jfy_regulator_login_log';
    }
}
