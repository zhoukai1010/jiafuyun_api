<?php

class Model_Jiafuyun_Regulator extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'zab_regulator';
        return 'jfy_regulator';
    }
}
