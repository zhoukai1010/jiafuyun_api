<?php

class Model_Jiafuyun_RegulatorConfig extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'zab_regulator_config';
        return 'jfy_regulator_config';
    }
}
