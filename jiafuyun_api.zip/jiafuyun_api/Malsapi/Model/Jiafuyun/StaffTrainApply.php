<?php

class Model_Jiafuyun_StaffTrainApply extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'jfb_company_staff_train_apply';
        return 'jfy_company_staff_train_apply';
    }
}
