<?php

class Model_Jiafuyun_CompanyLicense extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'jfb_company_license';
        return 'jfy_company_license';
    }
}
