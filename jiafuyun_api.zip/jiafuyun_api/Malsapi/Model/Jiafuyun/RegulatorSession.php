<?php

class Model_Jiafuyun_RegulatorSession extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'zab_regulator_session';
        return 'jfy_regulator_session';
    }
}
