<?php

class Model_Jiafuyun_CheckPlan extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'zab_check_plan';
        return 'jfy_check_plan';
    }
}
