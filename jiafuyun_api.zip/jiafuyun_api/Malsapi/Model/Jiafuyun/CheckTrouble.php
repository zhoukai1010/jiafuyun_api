<?php

class Model_Jiafuyun_CheckTrouble extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'zab_check_trouble';
        return 'jfy_check_trouble';
    }
}
