<?php

class Model_Jiafuyun_RegulatorLoginData extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'zab_regulator_login_data';
        return 'jfy_regulator_login_data';
    }
}
