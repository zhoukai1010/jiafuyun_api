<?php

class Model_Jiafuyun_Company extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'zab_company';
        return 'jfy_company';
    }
}
