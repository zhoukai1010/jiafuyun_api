<?php

class Model_Jiafuyun_Knowledge extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
//        return 'zab_knowledge';
        return 'jfy_knowledge';
    }
}
