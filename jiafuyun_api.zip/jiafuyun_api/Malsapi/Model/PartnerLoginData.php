<?php

class Model_PartnerLoginData extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
        return 'jfy_partner_login_data';
    }
}
