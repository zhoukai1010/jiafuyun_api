<?php

class Model_ChannelContractLog extends PhalApi_Model_NotORM {

    protected function getTableName($id) {
        return 'jfy_channel_contract_log';
    }
}
